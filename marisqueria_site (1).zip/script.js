// Botón WhatsApp con número personalizado
document.getElementById("whatsappLink").addEventListener("click", function(event) {
  event.preventDefault();
  const telefono = "521234567890"; // ← CAMBIA AQUÍ TU NÚMERO DE WHATSAPP
  const mensaje = "Hola, quiero más información sobre la marisquería.";
  const url = `https://wa.me/${telefono}?text=${encodeURIComponent(mensaje)}`;
  window.open(url, "_blank");
});
